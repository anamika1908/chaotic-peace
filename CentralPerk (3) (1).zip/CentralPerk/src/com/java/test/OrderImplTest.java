package com.java.test;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;


import com.java.cafe.OrderImpl;
import com.java.cafe.User;

import Exception.InvalidOrderException;

public class OrderImplTest {

	OrderImpl order;
	User user;
	
		@Before
	    public void init()
	    {
			order = Mockito.mock(OrderImpl.class);
			user = Mockito.mock(User.class);
	    }
	
	@Test
	public void testCalculatePrice() throws InvalidOrderException {
		 Mockito.when(order.calculatePrice(new String[]{"Chai","Coffee"})).thenReturn(9.0);
		    double bill = this.user.placeOrder("Chai,Coffee");
		   Assert.assertEquals(9.0,bill);
	}
}
