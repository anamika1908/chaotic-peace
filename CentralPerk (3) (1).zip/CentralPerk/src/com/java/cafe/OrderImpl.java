package com.java.cafe;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import Exception.InvalidOrderException;
public class OrderImpl  implements Order{

	public double placeOrder (String order) throws InvalidOrderException{

		String[] arr=order.split(",");

		if(arr[0].startsWith("-"))
		{
			throw new InvalidOrderException();
		}
		for(String item:arr)
		{
			if(item.charAt(0)!= '-')
			{
				if(!(Menu.getMenu().containsKey(item)))
				{
					System.out.println("Please look at the menu and Order again !!!!!");
					throw new InvalidOrderException();
				}
			}
		}
		validateExclusions(arr);
		return calculatePrice(arr);

	}

	public void validateExclusions(String[] order) throws InvalidOrderException{
		HashMap<String,ArrayList<String>> hm=new HashMap<String,ArrayList<String>>();
		for(int i=0;i<order.length;i++)
		{
			ArrayList<String> al=new ArrayList<String>();
			int j=i+1;
			while((j < order.length) && (order[j].startsWith("-") && (!order[i].startsWith("-"))))
			{
				al.add(order[j].substring(1));
				hm.put(order[i], al);
				j++;
			}
		}

		for (Entry<String, ArrayList<String>> entry : hm.entrySet())  {
			List<String> li1=Menu.getMenu().get(entry.getKey()).getIngredients();
			List<String> li2=entry.getValue();
			Collections.sort(li1);
			Collections.sort(li2);
			if(li2.equals(li1)){
			    System.out.println("You cannot exclude all the ingredients of : "+entry.getKey());
				throw new InvalidOrderException();
			}
		} 

	}



	public double calculatePrice(String[] order) throws InvalidOrderException{
		double value=0.0;
		for(String str:order)
		{
			if(!(str.startsWith("-")))
			{
				Item i= Menu.getMenu().get(str);
				value+=i.getPrice();
			}
			else
			{
				str=str.substring(1);
				if(Item.getCondiment().containsKey(str))
				value=value-Item.getCondiment().get(str);
				else{
					System.out.println("Invalid Exclusion");
					throw new InvalidOrderException();
				}
			}

			if(value<=0){
				throw new InvalidOrderException();
			}
		}
		return value;

	}


}
