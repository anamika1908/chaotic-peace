package com.java.cafe;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Menu {
	
	public static HashMap<String,Item> menu =new HashMap<String,Item>();
	
	static
	{
	     List<String> coffeeIngredient = new ArrayList<String>();
	     coffeeIngredient.add("coffee");
	     coffeeIngredient.add("milk");
	     coffeeIngredient.add("sugar");
	     coffeeIngredient.add("water");
	     Item i1= new Item("Coffee",5,coffeeIngredient);
	     menu.put("Coffee", i1);
	     List<String> teaIngredient = new ArrayList<String>(); 
	     teaIngredient.add("tea");
	     teaIngredient.add("sugar");
	     teaIngredient.add("milk");
	     teaIngredient.add("water");
	     Item i2 =new Item("Chai",4,teaIngredient);
	     menu.put("Chai", i2);
	     List<String> smootheIngredient = new ArrayList<String>(); 
	     smootheIngredient.add("banana");
	     smootheIngredient.add("sugar");
	     smootheIngredient.add("milk");
	     smootheIngredient.add("water");
	     Item i3 =new Item("Banana Smoothie",6,smootheIngredient);
	     menu.put("Banana Smoothie", i3);
	     List<String> shakeIngredient = new ArrayList<String>(); 
	     shakeIngredient.add("strawberries");
	     shakeIngredient.add("sugar");
	     shakeIngredient.add("milk");
	     shakeIngredient.add("water");
	     Item i4 =new Item("Strawberry Shake",7,shakeIngredient);
	     menu.put("Strawberry Shake", i4);
	     List<String> mojitoIngredient = new ArrayList<String>(); 
	     mojitoIngredient.add("lemon");
	     mojitoIngredient.add("sugar");
	     mojitoIngredient.add("soda");
	     mojitoIngredient.add("water");
	     mojitoIngredient.add("mint");
	     Item i5 =new Item("Mojito",(float) 7.5,mojitoIngredient);
	     menu.put("Mojito", i5);

	}

   public static void displayMenu(){
	   System.out.println("------------Menu of the Central Perk Cafe--------------");  
       menu.forEach((k,v) -> System.out.println(k+" for "+v.price));  
   }


public static HashMap<String, Item> getMenu() {
	return menu;
}


public static void setMenu(HashMap<String, Item> menu) {
	Menu.menu = menu;
}   
	     


}
