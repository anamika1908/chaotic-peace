package com.java.cafe;
import java.util.List;
import java.util.HashMap;
public class Item {
	static final HashMap<String,Double> condiment= new HashMap<String,Double>();
	public static HashMap<String, Double> getCondiment() {
		return condiment;
	}
	static
	{
		
		condiment.put("milk",  1.0);
		condiment.put("sugar", 0.5);
		condiment.put("soda", 0.5);
		condiment.put("mint",0.5);
		condiment.put("water", 0.5);
		condiment.put("coffee",0.5);
		condiment.put("banana", 0.5);
		condiment.put("tea", 0.5);
		condiment.put("strawberries",0.5);
		condiment.put("lemon", 0.35);
		
	}
	
	String itemName;
	float price;
	List<String> ingredients;
	
	public Item(String itemName, float price, List<String> ingredients) {
		super();
		this.itemName = itemName;
		this.price = price;
		this.ingredients = ingredients;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public List<String> getIngredients() {
		return ingredients;
	}
	public void setIngredients(List<String> ingredients) {
		this.ingredients = ingredients;
	}
  
}
