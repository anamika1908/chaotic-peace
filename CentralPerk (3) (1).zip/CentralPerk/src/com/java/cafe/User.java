package com.java.cafe;

import java.util.Scanner;

import Exception.InvalidOrderException;

public class User {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Menu.displayMenu();
		System.out.println("Please Enter your Order :");
		Scanner sc=new Scanner(System.in);
		String order=sc.next();
		
		try {
			Double price =new User().placeOrder(order);
			System.out.println("Order Placed Sucessfully. Total Bill: "+price);
		} catch (InvalidOrderException e) {
			System.out.println("Order is not Valid.Please try again");
			
		}
		finally{
			sc.close();
		}
		
	}
	public double placeOrder(String order) throws InvalidOrderException{
		Order or = new OrderImpl();
		 return or.placeOrder(order);
	}

}
