package com.java.cafe;

import Exception.InvalidOrderException;

public interface Order {

	
	void validateExclusions(String[] order) throws InvalidOrderException;;
	
	double calculatePrice(String[] order) throws InvalidOrderException; ;
	
	double placeOrder (String order) throws InvalidOrderException;
	
	
	
}
